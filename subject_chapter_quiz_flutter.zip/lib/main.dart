import 'package:flutter/material.dart';

void main() {
  runApp(QuizApp());
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Subject Chapter Quiz',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: SubjectScreen(),
    );
  }
}

class SubjectScreen extends StatelessWidget {
  final subjects = {
    "Maths": ["Algebra", "Geometry"],
    "Science": ["Physics", "Biology"]
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Subject")),
      body: ListView(
        children: subjects.keys.map((subject) {
          return ListTile(
            title: Text(subject),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChapterScreen(
                    subject: subject,
                    chapters: subjects[subject]!,
                  ),
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }
}

class ChapterScreen extends StatelessWidget {
  final String subject;
  final List<String> chapters;
  ChapterScreen({required this.subject, required this.chapters});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("$subject - Chapters")),
      body: ListView(
        children: chapters.map((chapter) {
          return ListTile(
            title: Text(chapter),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => QuizScreen(
                    subject: subject,
                    chapter: chapter,
                  ),
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }
}

class QuizScreen extends StatelessWidget {
  final String subject;
  final String chapter;

  QuizScreen({required this.subject, required this.chapter});

  final questions = [
    {
      "question": "What is 2 + 2?",
      "options": ["3", "4", "5"],
      "answer": "4",
      "type": "mcq"
    },
    {
      "question": "Define gravity.",
      "answer": "Gravity is the force that pulls objects towards the Earth.",
      "type": "short"
    },
    {
      "question": "Explain Newton's 3rd Law with example.",
      "answer": "Every action has an equal and opposite reaction. Example: Rocket launch.",
      "type": "long"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("$subject - $chapter Quiz")),
      body: ListView.builder(
        itemCount: questions.length,
        itemBuilder: (context, index) {
          var q = questions[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("${index + 1}. ${q['question']}",
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  if (q['type'] == 'mcq') ...[
                    ...(q['options'] as List<String>).map((opt) => ListTile(
                          title: Text(opt),
                          leading: Radio(
                            value: opt,
                            groupValue: q['answer'],
                            onChanged: (_) {},
                          ),
                        )),
                    Text("Correct Answer: ${q['answer']}",
                        style: TextStyle(color: Colors.green))
                  ] else ...[
                    Text("Answer: ${q['answer']}",
                        style: TextStyle(color: Colors.blue))
                  ]
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
